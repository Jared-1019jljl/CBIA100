/* Build & Brew — front-end-only campaign demonstration.
   No fetch, cookies, localStorage, analytics, form action, or data transmission. */
'use strict';

// Navigation on small screens.
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('#primary-nav');
function setMenu(open) {
  nav.classList.toggle('is-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
}
menuButton.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && nav.classList.contains('is-open')) {
    setMenu(false);
    menuButton.focus();
  }
});
window.addEventListener('resize', () => {
  if (window.innerWidth > 850) setMenu(false);
});

// Feature 1: Fixed, Philippine-time countdown.
// The campaign is fictional. End date is Nov 27, 2026 at 10 AM Asia/Manila (UTC+08).
const offerStart = new Date('2026-11-02T06:00:00+08:00').getTime();
const offerEnd = new Date('2026-11-27T10:00:00+08:00').getTime();
const countdownTitle = document.getElementById('countdown-title');
const countdownStatus = document.getElementById('countdown-status');
const countdownElements = ['days', 'hours', 'minutes', 'seconds'].map(id => document.getElementById(id));
let lastPhase = '';
function updateCountdown() {
  const now = Date.now();
  const phase = now < offerStart ? 'upcoming' : now >= offerEnd ? 'expired' : 'active';
  const remaining = Math.max(0, (phase === 'upcoming' ? offerStart : offerEnd) - now);
  const secs = Math.floor(remaining / 1000);
  const values = [Math.floor(secs / 86400), Math.floor(secs / 3600) % 24, Math.floor(secs / 60) % 60, secs % 60];
  values.forEach((value, i) => { countdownElements[i].textContent = String(value).padStart(2, '0'); });
  if (phase !== lastPhase) {
    countdownTitle.textContent = phase === 'upcoming' ? 'OFFER STARTS IN' : phase === 'expired' ? 'THE OFFER HAS ENDED' : 'OFFER ENDS IN';
    countdownStatus.textContent = phase === 'upcoming'
      ? 'Starts Nov 2, 2026 at 6:00 AM Philippine time.'
      : phase === 'expired'
        ? 'Expired Nov 27, 2026 at 10:00 AM Philippine time. Demo form remains available.'
        : 'Available on eligible weekdays only, 6:00–10:00 AM Philippine time.';
    lastPhase = phase;
  }
}
updateCountdown();
setInterval(updateCountdown, 1000);

// Feature 2: Interactive discount / group savings calculator.
// Uses only prices from the original plan: ₱210 regular and ₱149 promo.
const regularUnitPrice = 210;
const promoUnitPrice = 149;
const countMin = 1;
const countMax = 5;
let customerCount = 1;
const currency = new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', maximumFractionDigits: 0 });
const minusButton = document.getElementById('minus');
const plusButton = document.getElementById('plus');
function updateSavings() {
  document.getElementById('quantity').textContent = customerCount;
  document.getElementById('regular-total').textContent = currency.format(regularUnitPrice * customerCount);
  document.getElementById('promo-total').textContent = currency.format(promoUnitPrice * customerCount);
  document.getElementById('savings-total').textContent = currency.format((regularUnitPrice - promoUnitPrice) * customerCount);
  minusButton.disabled = customerCount <= countMin;
  plusButton.disabled = customerCount >= countMax;
}
minusButton.addEventListener('click', () => { customerCount = Math.max(countMin, customerCount - 1); updateSavings(); });
plusButton.addEventListener('click', () => { customerCount = Math.min(countMax, customerCount + 1); updateSavings(); });
updateSavings();

// Feature 3: Simulated lead form with accessible feedback.
// Intentionally does NOT collect, save, transmit, or log any submitted information.
const form = document.getElementById('lead-form');
const nameField = document.getElementById('full-name');
const emailField = document.getElementById('email');
const consentField = document.getElementById('consent');
const success = document.getElementById('form-success');
const restart = document.getElementById('restart-form');
function fieldError(field, message) {
  const errorEl = document.getElementById(field.id === 'full-name' ? 'name-error' : field.id === 'email' ? 'email-error' : 'consent-error');
  errorEl.textContent = message;
  field.setAttribute('aria-invalid', String(Boolean(message)));
}
function checkName() {
  const value = nameField.value.trim();
  const message = value.length < 2 || !/[A-Za-z\u00C0-\u024F]/.test(value) ? 'Please enter your name (at least 2 characters).' : '';
  fieldError(nameField, message);
  return !message;
}
function checkEmail() {
  const value = emailField.value.trim();
  const message = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) ? '' : 'Enter a valid email address, e.g. alex@example.com.';
  fieldError(emailField, message);
  return !message;
}
function checkConsent() {
  const message = consentField.checked ? '' : 'You must agree to the demonstration consent to proceed.';
  fieldError(consentField, message);
  return !message;
}
nameField.addEventListener('input', () => {
  if (nameField.getAttribute('aria-invalid') === 'true') checkName();
});
emailField.addEventListener('input', () => {
  if (emailField.getAttribute('aria-invalid') === 'true') checkEmail();
});
consentField.addEventListener('change', checkConsent);
form.addEventListener('submit', event => {
  event.preventDefault(); // No networking or navigation.
  const nameOkay = checkName();
  const emailOkay = checkEmail();
  const consentOkay = checkConsent();
  if (!nameOkay || !emailOkay || !consentOkay) {
    ( !nameOkay ? nameField : !emailOkay ? emailField : consentField ).focus();
    return;
  }
  // Never copy user-provided values anywhere. Show only a generic, fictional pass.
  form.hidden = true;
  success.hidden = false;
  success.focus();
});
restart.addEventListener('click', () => {
  form.reset();
  [nameField, emailField, consentField].forEach(field => fieldError(field, ''));
  success.hidden = true;
  form.hidden = false;
  nameField.focus();
});
